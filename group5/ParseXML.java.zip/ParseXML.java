package group5;

import stdlib.*;
import java.util.Stack;

public class ParseXML {


	public static void main(String[] args) {
		        
		StdOut.print("Please input your XML file pathname: ");
		String textFile = StdIn.readLine();
		
        final In in = new In(textFile);
        if (!in.exists ()) {
        	StdOut.println("Unable to open the text source " + textFile);
            System.exit (1);
        }

        final String inputExample = in.readAll();
        
		Stack<String> tagList = new Stack<>();
		String [] tokenList = inputExample.split("\\s+");

		
		for (int i = 0; i <= tokenList.length-1; i++) {
			String word = tokenList[i];
			XMLToken token2 = new XMLToken(word);

				if (token2.isOpeningTag()) {
					System.out.print(word);
					tagList.push(word);
				}
				
				else if (token2.isClosingTag() && !token2.isSelfClosingTag()) {
					System.out.print(word);
					if (tagList.isEmpty()) {
						StdOut.println("Error: A closing tag does not have a matching opening tag" + word);
						System.exit(0);
					}
					String lastItem = tagList.pop();
					word = word.replaceAll("<", "");
					word = word.replaceAll("/", "");
					word = word.replaceAll(">", "");
					lastItem = lastItem.replaceAll("<", "");
					lastItem = lastItem.replaceAll("/", "");
					lastItem = lastItem.replaceAll(">", "");
					if (!word.equals(lastItem)) {
						StdOut.println(word + "" + lastItem);
						StdOut.println("Error: A closing tag does not match its opening tag" + word);
						System.exit(0);
					}
				}
				else {
					System.out.println("\n" + word + "\n");
				}			
			}
		if (!tagList.isEmpty()) {
			StdOut.println("Error: There are opening tags with no matching closing tags" + tagList.toString());
		}
		
	}
}



